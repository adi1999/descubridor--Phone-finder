package com.example.aashish.smsreceiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.telephony.SmsMessage;
import android.util.Log;
import android.widget.Toast;

public class ReceiverSMS extends BroadcastReceiver {
private String Aashish="descubridor";



    @Override
    public void onReceive(Context context, Intent intent) {


        processReceive(context, intent);
    }

    private void processReceive(Context context, Intent intent) {
        Bundle extras = intent.getExtras();
        String message = "";
        String body = "";
        String address = "";

        // If receive a message
        if (extras != null) {
            // Get content message
            Object[] smsExtras = (Object[]) extras.get("pdus");

            // Read all message
            for (int i = 0; i < smsExtras.length; i++) {
                SmsMessage sms = SmsMessage.createFromPdu((byte[]) smsExtras[i]);

                // Get body
                body = sms.getMessageBody();

                // Get address
                address = sms.getOriginatingAddress();

                // Get message
                message += "SMS From : " + address + "\n Body : " + body+ "\n";

                // If phone number is special then play sound
                if (body.equals(Aashish)){
                    MainActivity.mp.reset();
                    MainActivity.mp= MediaPlayer.create(context, R.raw.oh);
                    MainActivity.mp.setLooping(true);
                    MainActivity.mp.start();
                }
            }

            Toast.makeText(context, message, Toast.LENGTH_LONG).show();
        }

    }

}
