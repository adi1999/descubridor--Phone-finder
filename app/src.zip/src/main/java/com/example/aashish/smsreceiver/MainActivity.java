package com.example.aashish.smsreceiver;

import android.Manifest;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.app.Activity;
import android.os.Parcelable;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends Activity {




    public static MediaPlayer mp;
    private void requestSmsPermission() {
        String permission = Manifest.permission.RECEIVE_SMS;
        int grant = ContextCompat.checkSelfPermission(this, permission);
        if ( grant != PackageManager.PERMISSION_GRANTED) {
            String[] permission_list = new String[1];
            permission_list[0] = permission;
            ActivityCompat.requestPermissions(this, permission_list, 1);
        }
    }



// Store EditText - Input in variable



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        requestSmsPermission();
        mp = MediaPlayer.create(MainActivity.this, R.raw.oh);

        Button btnStop =findViewById(R.id.btnStop);

        btnStop.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View view) {
                mp.stop();
                Toast.makeText(MainActivity.this, "Sound stopped !", Toast.LENGTH_LONG).show();
            }
        });
    }



}
